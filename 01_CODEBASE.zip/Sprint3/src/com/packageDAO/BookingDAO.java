package com.packageDAO;
import com.packageModel.*;
import database.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BookingDAO {
    public boolean createBooking(String bookingDate, String slot, String vendor, String address, int amount, String userId, String subserviceType) throws SQLException, ClassNotFoundException {
        String sql = "INSERT INTO Bookings (BookingDate, Slot, Vendor, Address, Amount, id, subserviceType) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, bookingDate);
            statement.setString(2, slot);
            statement.setString(3, vendor);
            statement.setString(4, address);
            statement.setInt(5, amount);
            statement.setString(6, userId);
            statement.setString(7, subserviceType);

            return statement.executeUpdate() > 0;
        }
    }
    
    public List<BookingHistory> getBookingHistoryByUserId(String userId) throws SQLException, ClassNotFoundException {
        List<BookingHistory> bookingsList = new ArrayList<>();
        String sql = "SELECT BookingId, BookingDate, Slot, Vendor, Amount,subserviceType FROM bookings WHERE id = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            
            statement.setString(1, userId);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    BookingHistory booking = new BookingHistory(
                            resultSet.getInt("BookingId"),
                            resultSet.getDate("BookingDate"),
                            resultSet.getString("Slot"),
                            resultSet.getString("Vendor"),
                            resultSet.getInt("Amount"),
                            resultSet.getString("subserviceType")
                    );
                    bookingsList.add(booking);
                }
            }
        }

        return bookingsList;
    }
}

