package com.packageDAO;

import database.DatabaseConnection;
import org.mindrot.jbcrypt.BCrypt;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginDAO {

    public boolean validateUser(String userId, String password) throws Exception {
        String query = "SELECT password FROM users WHERE id = ?";
        
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
             
            statement.setString(1, userId);
            ResultSet resultSet = statement.executeQuery();
            
            if (resultSet.next()) {
                String hashedPassword = resultSet.getString("password");
                return BCrypt.checkpw(password, hashedPassword); // Verify password
            } else {
                return false; // User ID does not exist
            }
        }
    }
}

