package com.packageDAO;

import database.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class RegistrationDAO {

    public RegistrationDAO() {
        // Optional: Ensure the driver loads once on class instantiation
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public boolean isFieldExists(String fieldName, String fieldValue) throws Exception {
        String sql = "SELECT 1 FROM users WHERE " + fieldName + " = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, fieldValue);
            ResultSet resultSet = statement.executeQuery();
            return resultSet.next();
        }
    }

    public boolean registerUser(String userId, String userName, String email, String hashedPassword, String address, String contact) throws Exception {
        String sql = "INSERT INTO users(id, userName, email, password, address, contact) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, userId);
            statement.setString(2, userName);
            statement.setString(3, email);
            statement.setString(4, hashedPassword);
            statement.setString(5, address);
            statement.setString(6, contact);
            return statement.executeUpdate() > 0;
        }
    }
}
