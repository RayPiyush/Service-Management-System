package com.packageDAO;
import java.sql.SQLException;
import java.util.List;

import com.packageModel.User;

public interface UserDAO {
    boolean isUsernameRegistered(String username) throws SQLException, ClassNotFoundException;
    boolean isEmailRegistered(String email) throws SQLException, ClassNotFoundException;
    boolean isContactRegistered(String contact) throws SQLException, ClassNotFoundException;
    boolean registerUser(User user) throws SQLException, ClassNotFoundException;
	boolean updateUserDetails(User user) throws SQLException, ClassNotFoundException;
	boolean deleteUserById(String userId) throws SQLException, ClassNotFoundException;
	List<User> getAllUsers() throws SQLException, ClassNotFoundException;
}

