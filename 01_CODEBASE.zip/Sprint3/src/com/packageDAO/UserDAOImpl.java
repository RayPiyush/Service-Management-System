package com.packageDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.packageModel.User;

import database.DatabaseConnection;

public class UserDAOImpl implements UserDAO {

    @Override
    public boolean isUsernameRegistered(String username) throws SQLException, ClassNotFoundException {
        String sql = "SELECT COUNT(*) FROM users WHERE userName = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, username);
            ResultSet result = statement.executeQuery();
            result.next();
            return result.getInt(1) > 0;
        }
    }

    @Override
    public boolean isEmailRegistered(String email) throws SQLException, ClassNotFoundException {
        String sql = "SELECT COUNT(*) FROM users WHERE email = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, email);
            ResultSet result = statement.executeQuery();
            result.next();
            return result.getInt(1) > 0;
        }
    }

    @Override
    public boolean isContactRegistered(String contact) throws SQLException, ClassNotFoundException {
        String sql = "SELECT COUNT(*) FROM users WHERE contact = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, contact);
            ResultSet result = statement.executeQuery();
            result.next();
            return result.getInt(1) > 0;
        }
    }
    
    public User getUserById(String userId) throws SQLException, ClassNotFoundException {
        String sql = "SELECT * FROM users WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, userId);
            ResultSet result = statement.executeQuery();

            if (result.next()) {
                // Create and populate a User object with the retrieved details
                User user = new User();
                user.setUserId(result.getString("id"));
                user.setUserName(result.getString("userName"));
                user.setEmail(result.getString("email"));
                user.setPassword(result.getString("password"));
                user.setAddress(result.getString("address"));
                user.setContact(result.getString("contact"));
                return user;
            }
        }
        return null; // Return null if no user is found
    }
    
    @Override
    public boolean updateUserDetails(User user) throws SQLException, ClassNotFoundException {
        String sql = "UPDATE users SET username = ?, email = ?, address = ?, contact = ? WHERE id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, user.getUserName());
            statement.setString(2, user.getEmail());
            statement.setString(3, user.getAddress());
            statement.setString(4, user.getContact());
            statement.setString(5, user.getUserId());
            
            return statement.executeUpdate() > 0;
        }
    }
    
    @Override
    public boolean deleteUserById(String userId) throws SQLException, ClassNotFoundException {
        String deleteBookingsSql = "DELETE FROM bookings WHERE id = ?";
        String deleteUserSql = "DELETE FROM users WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement deleteBookingsStmt = conn.prepareStatement(deleteBookingsSql);
             PreparedStatement deleteUserStmt = conn.prepareStatement(deleteUserSql)) {

            // Start transaction
            conn.setAutoCommit(false);

            // Delete from bookings table
            deleteBookingsStmt.setString(1, userId);
            deleteBookingsStmt.executeUpdate();

            // Delete from users table
            deleteUserStmt.setString(1, userId);
            int rowsDeleted = deleteUserStmt.executeUpdate();

            if (rowsDeleted > 0) {
                conn.commit();
                return true;
            } else {
                conn.rollback();
                return false;
            }

        } catch (SQLException e) {
            throw new SQLException("Error deleting user and related bookings: " + e.getMessage());
        }
    }
    
    @Override
    public List<User> getAllUsers() throws SQLException, ClassNotFoundException {
        List<User> userList = new ArrayList<>();
        String sql = "SELECT id, username, email, address, contact FROM users";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                User user = new User();
                user.setUserId(rs.getString("id"));
                user.setUserName(rs.getString("username"));
                user.setEmail(rs.getString("email"));
                user.setAddress(rs.getString("address"));
                user.setContact(rs.getString("contact"));
                
                userList.add(user);
            }
        }
        return userList;
    }
    
    @Override
    public boolean registerUser(User user) throws SQLException,ClassNotFoundException {
        String sql = "INSERT INTO users (id, username, email, password, address, contact) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, user.getUserId());
            stmt.setString(2, user.getUserName());
            stmt.setString(3, user.getEmail());
            stmt.setString(4, user.getPassword());
            stmt.setString(5, user.getAddress());
            stmt.setString(6, user.getContact());

            return stmt.executeUpdate() > 0;
        }
    }

    // Method to generate unique 7-digit ID
    public String generateUniqueUserId() throws SQLException, ClassNotFoundException {
        String userId;
        try (Connection conn = DatabaseConnection.getConnection()) {
            do {
                userId = String.format("%07d", new java.util.Random().nextInt(10000000));
                String checkIdSql = "SELECT COUNT(*) FROM users WHERE id = ?";
                try (PreparedStatement checkIdStmt = conn.prepareStatement(checkIdSql)) {
                    checkIdStmt.setString(1, userId);
                    try (ResultSet rs = checkIdStmt.executeQuery()) {
                        if (rs.next() && rs.getInt(1) == 0) {
                            break;
                        }
                    }
                }
            } while (true);
        }
        return userId;
    }
}

