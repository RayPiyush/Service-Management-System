package com.packageModel;


public class Booking {
    private String bookingDate;
    private String slot;
    private String vendor;
    private String address;
    private int amount;
    private String userId;
    private String subserviceType;
    
    public String getSubserviceType() {
		return subserviceType;
	}
	public void setSubserviceType(String subserviceType) {
		this.subserviceType = subserviceType;
	}
    
    public String getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}
	public String getSlot() {
		return slot;
	}
	public void setSlot(String slot) {
		this.slot = slot;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}

    
}




//
//
//public class Booking {
//    private String bookingDate;
//    private String slot;
//    private String vendor;
//    private String address;
//    private int amount;
//    private String userId;
//    
//    public String getBookingDate() {
//		return bookingDate;
//	}
//	public void setBookingDate(String bookingDate) {
//		this.bookingDate = bookingDate;
//	}
//	public String getSlot() {
//		return slot;
//	}
//	public void setSlot(String slot) {
//		this.slot = slot;
//	}
//	public String getVendor() {
//		return vendor;
//	}
//	public void setVendor(String vendor) {
//		this.vendor = vendor;
//	}
//	public String getAddress() {
//		return address;
//	}
//	public void setAddress(String address) {
//		this.address = address;
//	}
//	public int getAmount() {
//		return amount;
//	}
//	public void setAmount(int amount) {
//		this.amount = amount;
//	}
//	public String getUserId() {
//		return userId;
//	}
//	public void setUserId(String userId) {
//		this.userId = userId;
//	}
//
//    
//}
//
