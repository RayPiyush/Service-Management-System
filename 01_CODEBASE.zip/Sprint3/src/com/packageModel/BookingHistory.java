package com.packageModel;


import java.sql.Date;

public class BookingHistory {
   
    private int bookingId;
    private Date bookingDate;
    private String slot;
    private String vendor;
    private int amount;
    private String serviceType;
    public BookingHistory(int bookingId, Date bookingDate, String slot, String vendor, int amount, String serviceType) {
        this.bookingId = bookingId;
        this.bookingDate = bookingDate;
        this.slot = slot;
        this.vendor = vendor;
        this.amount = amount;
        this.serviceType = serviceType;
    }

    // Getters
    public int getBookingId() { return bookingId; }
    public Date getBookingDate() { return bookingDate; }
    public String getSlot() { return slot; }
    public String getVendor() { return vendor; }
    public int getAmount() { return amount; }
    public String getServiceType(){return serviceType;}
    
    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    public void setBookingDate(Date bookingDate) {
        this.bookingDate = bookingDate;
    }

    public void setSlot(String slot) {
        this.slot = slot;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
    public void setServicetype(String serviceType) {
        this.serviceType = serviceType;
    }
}

