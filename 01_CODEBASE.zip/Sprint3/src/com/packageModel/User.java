package com.packageModel;
import java.util.*;

public class User {
    
	private String id;
    private String userName;
    private String email;
    private String password;
    private String address;
    private String contact;
    private List<Booking> bookingHistory; 
    
    
    public String getUserId() {
		return id;
	}
	public void setUserId(String id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	
	public List<Booking> getBookingHistory() {
        return bookingHistory;
    }

    public void setBookingHistory(List<Booking> bookingHistory) {
        this.bookingHistory = bookingHistory;
    }
	//method to showalluser
    public Map<String, String> toMap() {
        Map<String, String> userMap = new HashMap<>();
        userMap.put("userId", this.id);
        userMap.put("username", this.userName);
        userMap.put("email", this.email);
        userMap.put("address", this.address);
        userMap.put("contact", this.contact);
        return userMap;
    }
    
}
