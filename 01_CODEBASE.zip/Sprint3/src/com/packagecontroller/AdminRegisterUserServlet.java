package com.packagecontroller;

import com.packageDAO.UserDAOImpl;
import com.packageModel.User;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import java.io.IOException;

import org.mindrot.jbcrypt.BCrypt;

@WebServlet("/AdminRegisterUserServlet")
public class AdminRegisterUserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserDAOImpl userDAO;

    public void init() {
        userDAO = new UserDAOImpl();
    }
    
    public static String HashPassword(String m) {
        return BCrypt.hashpw(m, BCrypt.gensalt());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String address = request.getParameter("address");
        String contact = request.getParameter("contact");

        try {
            // Generate a unique user ID
            String userId = userDAO.generateUniqueUserId();
            
            String hashedPassword = HashPassword(password);

            // Create User object
            User user = new User();
            user.setUserId(userId);
            user.setUserName(username);
            user.setEmail(email);
            user.setPassword(hashedPassword);
            user.setAddress(address);
            user.setContact(contact);

            // Register user
            if (userDAO.registerUser(user)) {
                request.setAttribute("userId", userId);
                RequestDispatcher rd = request.getRequestDispatcher("/adminUseRegAck.jsp");
                rd.forward(request, response);
            } else {
                response.getWriter().println("Failed to register user.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error occurred: " + e.getMessage());
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher rd = request.getRequestDispatcher("/adminDashboard.jsp");
        rd.forward(request, response);
    }
}





















