package com.packagecontroller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String ADMIN_USER_ID = "admin";
    private static final String ADMIN_PASSWORD = "password123";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userId = request.getParameter("userId");
        String password = request.getParameter("password");

        if (ADMIN_USER_ID.equals(userId) && ADMIN_PASSWORD.equals(password)) {
        	 HttpSession session = request.getSession(true);
             session.setAttribute("adminId", ADMIN_USER_ID);
            response.sendRedirect("adminDashboard.jsp");
        } else {
            response.getWriter().println("Invalid credentials! Please try again.");
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	// TODO Auto-generated method stub
    	RequestDispatcher rd=req.getRequestDispatcher("/adminDashboard.jsp");
		rd.forward(req,resp);
    }
}