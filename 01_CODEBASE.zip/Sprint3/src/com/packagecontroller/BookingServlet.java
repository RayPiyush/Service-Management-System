package com.packagecontroller;

import com.packageDAO.BookingDAO;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/BookingServlet")
public class BookingServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private BookingDAO bookingDAO;

    public void init() {
        bookingDAO = new BookingDAO();
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();

        // Retrieve user input
        String bookingDate = req.getParameter("date");
        String bkslot = req.getParameter("slot");
        String bkvendor = req.getParameter("vendor");
        String bkaddress = req.getParameter("address");
        String amountStr = req.getParameter("amount");
        String subservice = req.getParameter("subservice"); // Retrieve the subservice
        int bkamount = 0;
        if (amountStr != null && !amountStr.isEmpty()) {
            try {
                bkamount = Integer.parseInt(amountStr);
            } catch (NumberFormatException e) {
                out.print("<h3 style='color:red'>Invalid amount format.</h3>");
                return;
            }
        } else {
            out.print("<h3 style='color:red'>Amount is missing.</h3>");
            return;
        }

        HttpSession session = req.getSession(false);
        if (session != null) {
            String userId = (String) session.getAttribute("userId");
            if (userId == null) {
                out.print("<h3 style='color:red'>User is not logged in. Please log in to book a service.</h3>");
                return;
            }

            try {
                // Use DAO to create a booking
                boolean isBookingSuccessful = bookingDAO.createBooking(bookingDate, bkslot, bkvendor, bkaddress, bkamount, userId, subservice);

                if (isBookingSuccessful) {
                    RequestDispatcher rd = req.getRequestDispatcher("/confirm.jsp");
                    rd.include(req, resp);
                } else {
                    out.print("<h3 style='color:red'>Booking failed.</h3>");
                    RequestDispatcher rd = req.getRequestDispatcher("/subservice1single.jsp");
                    rd.include(req, resp);
                }
            } catch (Exception e) {
                e.printStackTrace();
                out.print("<h3 style='color:red'>Error: " + e.getMessage() + "</h3>");
                RequestDispatcher rd = req.getRequestDispatcher("/subservice1single.jsp");
                rd.include(req, resp);
            }
        } else {
            out.print("<h3 style='color:red'>Session has expired. Please log in again.</h3>");
        }
    }
}




