package com.packagecontroller;

import com.packageDAO.UserDAO;
import com.packageDAO.UserDAOImpl;
import com.packageModel.User;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/Crud1Servlet")
public class Crud1Servlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserDAO userDAO;

    public void init() {
        userDAO = new UserDAOImpl(); // Initialize the DAO implementation
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Retrieve form data from request
        String id = request.getParameter("userId");
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String address = request.getParameter("address");
        String contact = request.getParameter("contact");

        PrintWriter out = response.getWriter();

        try {
            // Create a User object with updated data
            User user = new User();
            user.setUserId(id);
            user.setUserName(username);
            user.setEmail(email);
            user.setAddress(address);
            user.setContact(contact);

            // Use DAO to update user details
            boolean isUpdated = userDAO.updateUserDetails(user);

            if (isUpdated) {
                RequestDispatcher rd = request.getRequestDispatcher("/ackUserCrud.jsp");
                rd.forward(request, response);
            } else {
                out.println("User not found or no changes made.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            out.println("Error updating user details: " + e.getMessage());
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        RequestDispatcher rd = req.getRequestDispatcher("/ackUserCrud.jsp");
        rd.forward(req, resp);
    }
}











