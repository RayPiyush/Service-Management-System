package com.packagecontroller;

import com.packageDAO.UserDAO;
import com.packageDAO.UserDAOImpl;
import com.packageModel.User;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import java.io.IOException;

@WebServlet("/Crud2Servlet")
public class Crud2Servlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserDAO userDAO;

    public void init() {
        userDAO = new UserDAOImpl(); // Initialize DAO
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Retrieve the userId from the request
        String userId = request.getParameter("reid");

        try {
            // Use DAO to delete the user and related bookings
            boolean isDeleted = userDAO.deleteUserById(userId);

            if (isDeleted) {
                // Forward to success page if deletion was successful
                RequestDispatcher rd = request.getRequestDispatcher("/crud2success.jsp");
                rd.forward(request, response);
            } else {
                // Forward to an error page if the user was not found
                request.setAttribute("errorMessage", "No user found with ID " + userId);
                RequestDispatcher rd = request.getRequestDispatcher("/crud2error.jsp");
                rd.forward(request, response);
            }
        } catch (Exception e) {
            // Handle any exceptions
            request.setAttribute("errorMessage", "Error deleting user: " + e.getMessage());
            RequestDispatcher rd = request.getRequestDispatcher("/crud2error.jsp");
            rd.forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        RequestDispatcher rd = req.getRequestDispatcher("/crud2success.jsp");
        rd.forward(req, resp);
    }
}

