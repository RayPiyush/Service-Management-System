package com.packagecontroller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/LogoutServlet")
public class LogoutServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get the current session
        HttpSession session = request.getSession(false); // Fetch session if exists, don't create a new one

        if (session != null) {
            // Invalidate the session
            session.invalidate();
           
        }
      //prevents caching at the proxy server
        response.setHeader("Cache-Control","no-cache"); //HTTP 1.1 
        response.setHeader("Pragma","no-cache"); //HTTP 1.0 
        response.setDateHeader ("Expires", 0);
        // Redirect to login page or home page after logout
        response.sendRedirect("index.jsp");  // Replace with your login page or home page URL
    }
}
