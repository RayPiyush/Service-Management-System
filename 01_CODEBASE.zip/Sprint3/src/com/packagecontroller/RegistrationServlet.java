package com.packagecontroller;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import org.mindrot.jbcrypt.BCrypt;
import com.packageDAO.RegistrationDAO;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private RegistrationDAO registrationDAO;

    @Override
    public void init() {
    	registrationDAO = new RegistrationDAO();
    }

    public static String HashPassword(String m) {
        return BCrypt.hashpw(m, BCrypt.gensalt());
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();
        String userName = req.getParameter("userName");
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String confirmPassword = req.getParameter("cfpassword");
        String address = req.getParameter("address");
        String contact = req.getParameter("contactNumber");

        if (!password.equals(confirmPassword)) {
            resp.getWriter().write("Passwords do not match!");
            return;
        }

        Random random = new Random();
        int userIdInt = 1000000 + random.nextInt(9000000);
        String userId = Integer.toString(userIdInt);
      
        boolean hasError = false;

        try {
            if (registrationDAO.isFieldExists("userName", userName)) {
                req.setAttribute("userNameError", "Username already exists.");
                hasError = true;
            }

            if (registrationDAO.isFieldExists("email", email)) {
                req.setAttribute("emailError", "Email is already registered.");
                hasError = true;
            }

            if (registrationDAO.isFieldExists("contact", contact)) {
                req.setAttribute("contactError", "Contact number is already registered.");
                hasError = true;
            }

            if (hasError) {
                RequestDispatcher rd = req.getRequestDispatcher("/Error.jsp");
                rd.forward(req, resp);
                return;
            }

            String hashedPassword = HashPassword(password);
            if (registrationDAO.registerUser(userId, userName, email, hashedPassword, address, contact)) {
//            	System.out.println(userId);
                req.setAttribute("userId", userId);
                req.setAttribute("userName", userName);
                req.setAttribute("email", email);
//                HttpSession session = req.getSession(true);
//                session.setAttribute("userId", userId);
//                session.setAttribute("userName", userName);
                RequestDispatcher rd = req.getRequestDispatcher("/acknowledgment.jsp");
                rd.include(req, resp);
            } else {
                resp.setContentType("text/html");
                out.print("<h3 style='color:red'>User Not Registered Successfully</h3>");
                RequestDispatcher rd = req.getRequestDispatcher("/registration.jsp");
                rd.include(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.setContentType("text/html");
            out.print("<h3 style='color:red'>Error is: " + e.getMessage() + "</h3>");
            RequestDispatcher rd = req.getRequestDispatcher("/registration.jsp");
            rd.include(req, resp);
        }
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        RequestDispatcher rd = req.getRequestDispatcher("/registration.jsp");
        rd.forward(req, resp);
    }
}


