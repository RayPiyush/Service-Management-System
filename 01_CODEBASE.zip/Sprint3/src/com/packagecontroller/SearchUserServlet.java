package com.packagecontroller;

import java.io.IOException;
import java.sql.SQLException;

import com.packageDAO.UserDAOImpl;
import com.packageModel.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/SearchUserServlet")
public class SearchUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userId = request.getParameter("userId");
        request.getSession(true).setAttribute("ADuserID", userId);
        // Create an instance of UserDAOImpl to interact with the database
        UserDAOImpl userDAO = new UserDAOImpl();
        User user = null;
        
        try {
            // Fetch the user by their ID
            user = userDAO.getUserById(userId);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            // If there is an error, you can set an error attribute and redirect
            request.setAttribute("error", "Unable to fetch user details.");
        }
        System.out.println(user);

        // If user is found, set the user object as a request attribute
        if (user != null) {
            request.setAttribute("user", user);
            // Forward the request to the JSP to display user details
            RequestDispatcher dispatcher = request.getRequestDispatcher("crud.jsp");
            dispatcher.forward(request, response);
        } else {
            // If no user is found, forward with an error message
            request.setAttribute("message", "User not found");
            RequestDispatcher dispatcher = request.getRequestDispatcher("nouserfound.jsp");
            dispatcher.forward(request, response);
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	// TODO Auto-generated method stub
    	RequestDispatcher rd=req.getRequestDispatcher("/nouserfound.jsp");
		rd.forward(req,resp);
    	
    	
    }
}


