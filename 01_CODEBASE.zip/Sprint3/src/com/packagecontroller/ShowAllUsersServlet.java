package com.packagecontroller;

import com.packageDAO.UserDAO;
import com.packageDAO.UserDAOImpl;
import com.packageModel.User;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import java.io.IOException;
import java.util.List;

@WebServlet("/ShowAllUsersServlet")
public class ShowAllUsersServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserDAO userDAO;

    public void init() {
        userDAO = new UserDAOImpl(); // Initialize the DAO
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // Retrieve all users using the DAO
            List<User> userList = userDAO.getAllUsers();

            // Set the user list as a request attribute for the JSP
            request.setAttribute("userList", userList);

            // Forward to JSP page to display all users
            request.getRequestDispatcher("showAllUsers.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error retrieving user list: " + e.getMessage());
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }
}


